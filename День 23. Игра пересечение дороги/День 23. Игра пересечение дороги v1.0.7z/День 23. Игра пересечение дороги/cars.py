from turtle import Turtle
from random import choice, randint

COLORS = ['LightCoral', 'orange', 'khaki', 'green', 'blue', 'purple'] # палитра цветов
MOVE_INCREMENT = 3 # шаг увеличение скорости
STEP = 5 # начальная скорость авто
X_START_R_CAR = 300 # стартовая точка авто, начинающей движение с правой стороны
X_END_R_CAR = -300 # финишная точка авто, начинающей движение с правой стороны

class Car():

    def __init__(self):
        self.all_cars = []
        self.car_speed = STEP

    def create_car(self): # Создаём одну машину и помещаем в список машин
        num = randint(1, 6)
        if num == 1:
            new_car = Turtle()
            new_car.penup()
            new_car.color(choice(COLORS))
            new_y = randint(-240, 240)
            new_car.goto(X_START_R_CAR, new_y)
            new_car.shape('square')
            new_car.shapesize(stretch_len=2, stretch_wid=1)
            self.all_cars.append(new_car)


    def move_left(self): # Движение слева направо
        for car in self.all_cars:
            car.forward(-self.car_speed)

    def speed_up(self): # Увеличение скорости авто
        self.car_speed += MOVE_INCREMENT
